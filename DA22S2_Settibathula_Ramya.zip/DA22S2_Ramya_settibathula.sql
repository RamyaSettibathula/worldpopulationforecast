use population;

-- Display the dataset after pushing from python 
select * from forecastworld;

-- Display the top 10 population values with countries and years.
select country, population, years from forecastworld order by population desc limit 10 ;
-- Interpretation :- In India and china countries have highest number of population in future years too.

-- Display top 10 urban population values with countries
select country, Urban_Population from forecastworld order by Urban_Population desc limit 10 ;
-- Interpretation :- In India and china countries have highest number of urban population in future years too.

-- Identify top 10 Rank countries names with their rank also.
select country, Ranks from forecastworld where Ranks between 1 and 10 order by Ranks ;
-- Nearly 12 countries are under the top 10 rank in population. top three ranks are goes to India, China and USA.

-- Display the highest to lowest fertility rate with country names.
select country, Fertility_Rate from forecastworld  order by  Fertility_Rate desc;
-- Interpretation :- Nigeria have highest fertility rate with 6.95 and USA have lowest fertility rate with 2.05 and India have 2.24 fertility rate.

-- Display the median age in India 
select country,Median_Age from forecastworld where country = 'India' 
-- Interpretation :- The Indian median age is between 28 to 38 that means most of the Indian population is in between 28 - 38 age range. 